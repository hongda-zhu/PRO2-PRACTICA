var searchData=
[
  ['total_5fmemory_150',['total_memory',['../classProcesador.html#ac8e39453112cc9526fc732f57400f795',1,'Procesador']]]
];
