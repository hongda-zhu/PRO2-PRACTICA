var searchData=
[
  ['fit_5fjob_20',['fit_job',['../classProcesador.html#a6951cd8b6d3ede1227b13f0cd894ba6f',1,'Procesador']]],
  ['free_5fmemory_21',['free_memory',['../classProcesador.html#ac767e9a6816929e185efc47417792775',1,'Procesador']]]
];
