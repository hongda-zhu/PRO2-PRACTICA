var searchData=
[
  ['jobs_37',['jobs',['../classPrioridad.html#a986a1ea84c0b5a909f966d141a607114',1,'Prioridad']]]
];
