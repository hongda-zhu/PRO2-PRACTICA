var searchData=
[
  ['n_5faccepted_142',['n_accepted',['../classPrioridad.html#a7c78f5f53ae60186c2b93baff6612b3d',1,'Prioridad']]],
  ['n_5frejected_143',['n_rejected',['../classPrioridad.html#aab9aeea82059d6fd5beb781365275c4e',1,'Prioridad']]]
];
