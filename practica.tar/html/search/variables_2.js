var searchData=
[
  ['id_136',['id',['../classProceso.html#aedb36cca995b8b23d2e3d3739d30b216',1,'Proceso']]],
  ['id_5fjobs_137',['id_jobs',['../classPrioridad.html#af787fef4d9aad73fd65dddf15fa8e901',1,'Prioridad']]],
  ['id_5fprcd_138',['id_prcd',['../classProcesador.html#aeb45f597332731116cde14239327ee46',1,'Procesador']]]
];
