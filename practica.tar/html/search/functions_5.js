var searchData=
[
  ['i_5fconfigurar_5fcluster_106',['i_configurar_cluster',['../classCluster.html#aaee70807657139948f45a1af6930f2d5',1,'Cluster']]],
  ['i_5fenviar_5fprocesos_5fcluster_107',['i_enviar_procesos_cluster',['../classCluster.html#aa1758a8062d6d51947f5c13d3968eb72',1,'Cluster']]],
  ['i_5fimprimir_5festructura_5fcluster_108',['i_imprimir_estructura_cluster',['../classCluster.html#a60024ff88bc33277779770c5caec2f10',1,'Cluster']]],
  ['i_5fmodificar_5fcluster_109',['i_modificar_cluster',['../classCluster.html#a004c4dbfc9a1d90db7b3034b40e5cbe4',1,'Cluster']]],
  ['imprimir_5farea_5fespera_110',['imprimir_area_espera',['../classArea__Espera.html#aa6ff6d0df40c1ea60d359c725c9d319a',1,'Area_Espera']]],
  ['imprimir_5festructura_5fcluster_111',['imprimir_estructura_cluster',['../classCluster.html#a948d7075f9b30c2885ce804029e5ab25',1,'Cluster']]],
  ['imprimir_5fprioridad_112',['imprimir_prioridad',['../classArea__Espera.html#ac310b3e7c1001f61939d8f8682363dba',1,'Area_Espera']]],
  ['imprimir_5fprocesador_113',['imprimir_procesador',['../classCluster.html#a22282c9875715561063908874b0d515f',1,'Cluster']]],
  ['imprimir_5fprocesadores_5fcluster_114',['imprimir_procesadores_cluster',['../classCluster.html#ab8a628286f8a977063ea4395d9a422bf',1,'Cluster']]],
  ['imprimir_5fprocesos_115',['imprimir_procesos',['../classProcesador.html#a878f54f3bf0c2252046346b0b3ed069b',1,'Procesador']]],
  ['insert_5fgap_116',['insert_gap',['../classProcesador.html#a4171c0fef3de19f5398a49332f2ced1a',1,'Procesador']]]
];
