var searchData=
[
  ['actualizar_5fproceso_89',['actualizar_proceso',['../classProceso.html#ad0814d7e11e57da36edd67ecee7c0205',1,'Proceso']]],
  ['alta_5fprioridad_90',['alta_prioridad',['../classArea__Espera.html#a192601262a8b4c06261bd45b64d3a129',1,'Area_Espera']]],
  ['alta_5fproceso_5fespera_91',['alta_proceso_espera',['../classArea__Espera.html#a00686288be48be56fcc5b63e59961958',1,'Area_Espera::alta_proceso_espera()'],['../classPrioridad.html#ac6583ca7e63d58df58a3bcd616e14d0c',1,'Prioridad::alta_proceso_espera()']]],
  ['alta_5fproceso_5fprocesador_92',['alta_proceso_procesador',['../classCluster.html#afb280fbaa405ad18c4c6a51dfed6fd77',1,'Cluster::alta_proceso_procesador()'],['../classProcesador.html#af4c772af04008c3e72fcaad4e72ad4d1',1,'Procesador::alta_proceso_procesador()']]],
  ['area_5fespera_93',['Area_Espera',['../classArea__Espera.html#a260d02d0043e1fd9d8ce6e08de930c63',1,'Area_Espera']]],
  ['avanzar_5ftiempo_94',['avanzar_tiempo',['../classCluster.html#a3b93301a46cfa8cadf8d0121e234c386',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a91055a2cc9c3129051a762a9eb2a1f19',1,'Procesador::avanzar_tiempo()']]]
];
