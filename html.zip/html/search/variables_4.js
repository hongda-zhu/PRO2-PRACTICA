var searchData=
[
  ['left_5ftime_140',['left_time',['../classProceso.html#a120843be0790adaf95c76b82fbd0b482',1,'Proceso']]]
];
