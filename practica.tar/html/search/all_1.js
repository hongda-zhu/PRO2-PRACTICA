var searchData=
[
  ['baja_5fprioridad_8',['baja_prioridad',['../classArea__Espera.html#ad8e5063a95aedd070cf4df34fb7a38a1',1,'Area_Espera']]],
  ['baja_5fproceso_5fprocesador_9',['baja_proceso_procesador',['../classCluster.html#a805b6e3a4e6bd4273e2cda569820ff0b',1,'Cluster::baja_proceso_procesador()'],['../classProcesador.html#a5b54b24d643e29f156ff1d31f43712fb',1,'Procesador::baja_proceso_procesador(const int id_job)']]],
  ['best_5ffit_10',['best_fit',['../classProcesador.html#a6182c5640705bccf588e10d1cc3d113f',1,'Procesador']]]
];
