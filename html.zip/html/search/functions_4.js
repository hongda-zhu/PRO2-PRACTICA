var searchData=
[
  ['fit_5fjob_105',['fit_job',['../classProcesador.html#a6951cd8b6d3ede1227b13f0cd894ba6f',1,'Procesador']]]
];
