var searchData=
[
  ['print_120',['print',['../classProceso.html#ae24b37e6c570e60b4755a60f05ab0e9d',1,'Proceso']]],
  ['prioridad_121',['Prioridad',['../classPrioridad.html#a239123296380077ef6959111bf599a90',1,'Prioridad']]],
  ['procesador_122',['Procesador',['../classProcesador.html#ac7d20b90cc6c3e82cd5644623644ee4a',1,'Procesador']]],
  ['proceso_123',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]]
];
