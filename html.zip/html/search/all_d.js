var searchData=
[
  ['size_70',['size',['../classProceso.html#a93aae145e1e6845e9b95ba689e84968a',1,'Proceso']]]
];
