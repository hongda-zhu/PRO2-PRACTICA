var searchData=
[
  ['read_124',['read',['../classProceso.html#a976a78c5243449faaad4ed7b01e8a097',1,'Proceso']]],
  ['retrieve_5ffree_5fmemory_125',['retrieve_free_memory',['../classProcesador.html#a936dfd63b43a70b070b152d391bd3aec',1,'Procesador']]],
  ['retrieve_5fid_126',['retrieve_id',['../classProceso.html#a1a74ae0ef5b19a8c9c791caae9aeaa0a',1,'Proceso']]],
  ['retrieve_5finfo_127',['retrieve_info',['../classPrioridad.html#a287ae102cd4ef391292d69e61d23c724',1,'Prioridad']]],
  ['retrieve_5fjob_128',['retrieve_job',['../classPrioridad.html#acc0e8cbe0c58bfbe768d9ae4e95d5b5d',1,'Prioridad']]],
  ['retrieve_5fjobs_129',['retrieve_jobs',['../classPrioridad.html#a3cf29cb5813a50a4c73a313fb96b48b5',1,'Prioridad']]],
  ['retrieve_5fjobs_5fsize_130',['retrieve_jobs_size',['../classPrioridad.html#a2bc82144bbf93880041edc436ba64410',1,'Prioridad']]],
  ['retrieve_5fsize_131',['retrieve_size',['../classProceso.html#ac692b2c0c5ca17d3e799a3658383a8a0',1,'Proceso']]],
  ['retrieve_5ftime_132',['retrieve_time',['../classProceso.html#af3c26b5bc25b2f26cf171973b94b871e',1,'Proceso']]]
];
