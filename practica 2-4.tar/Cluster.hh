/** @file Cluster.hh
    @brief Especificación de la clase Cluster
*/

#ifndef CLUSTER_HH
#define CLUSTER_HH

#include "Procesador.hh"
#include "Proceso.hh"
#include "BinTree.hh"

#ifndef NO_DIAGRAM
#include <map>
#endif 

/** @class Cluster
 *  @brief FALTA EXPLICACION
*/
class Cluster {

    private:
    BinTree<string>prcd;
    map<string, Procesador>prcd_data; 
    void set_cluster (BinTree<string> &procesadores, map<string,Procesador> &procesadores_data);
    /**
     * @brief: Setter de configurar_cluster
     * \pre Recibe la referencia del árbol cluster construido por procesadores, el árbol tiene que ser vacío<
     * \post El resultado sería el cluster configurado, en otras palabras, el árbol de cluster con los nodos correspondientes seteados de orden correcto
    */

    void get_cluster_structure (BinTree<string>& prcd) const;
    /**
    * @brief: Getter recursiva de imprimir_estructura_cluster
    * \pre Recibe la referencia de arbol
    * \post Imprime el resultado de forma ordenado creciente del árbol binario
   */

    public:

    //Constructoras

    /** @brief Creadora de Cluster
    * \pre <em>cierto</em>
    * \post Devuelve un Cluster vacio.
    */
    Cluster();

    //Modificadoras

    void alta_proceso_procesador (string id_prcd, Proceso Job);
    /** @brief Modificadora del Cluster.
     * \pre <em>cierto</em>
     * \post Se añade un proceso en el procesado del id indicado o imprime un error porque no existe el procesador con el id indicado
    */
   
    void baja_proceso_procesador (string id_prcd, int id_job);
    /** @brief Modificadora del Cluster.
     * \pre <em>cierto</em>
     * \post Se elimina un proceso en el procesado del id indicado o imprime un error porque ya existe un proceso con el mismo id en el procesador.
    */  

    void configurar_cluster (); 
    /** @brief Modificadora del Cluster.
     * \pre <em>cierto</em>
     * \post Devuleve el arbol de procesadores del cluster por el orden creciente de los identificadores correspondientes
    */

    void avanzar_tiempo(int t);
    /** @brief Modificadora del Cluster.
     * \pre <em>cierto</em>
     * \post Se accelera todos el tiempo de todo los procesadores pendientes, si el tiempo restante 't' es mayor que el tiempo que queda un procesador, este procesador se queda eliminado y liberamos su espacio
    */  

   // Consultora


   // Lectura y escriptura

       void imprimir_procesadores_cluster();
    /** @brief Escriptura del Cluster.
     * \pre <em>Cierto></em>
     * \post Se imprime el listado de procesadores del cluster por el orden creciente de identificador
    */    

    void imprimir_estructura_cluster();
    /** @brief Escriptura del Cluster.
     * \pre <em>cierto</em>
     * \post se imprime la estructura de procesadores en forma creciente de primera posición de prcd_data
    */

   void imprimir_procesador(string id_procesador);
    /** @brief Escriptura del Cluster.
     * \pre Requiere el id valido de un procesador
     * \post se imprime los procesos de dicho profcesador por orden creciente de primera posición de memoria, incluyendo dicha posición y sus datos detallados 
    */
   


    
};
#endif