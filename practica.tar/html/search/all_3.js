var searchData=
[
  ['enviar_5fprocesos_5fcluster_17',['enviar_procesos_cluster',['../classArea__Espera.html#a6c31311bfa69edac2d8b193420739796',1,'Area_Espera::enviar_procesos_cluster()'],['../classCluster.html#ac68ae780311e6cd42711e8c8342aae25',1,'Cluster::enviar_procesos_cluster()']]],
  ['erase_5fgap_18',['erase_gap',['../classProcesador.html#ad30d3a61a7cb39faee7aec638422a356',1,'Procesador']]],
  ['exist_5fjob_19',['exist_job',['../classProcesador.html#a83f3690af72a494d9bbfc20b4a024fd0',1,'Procesador']]]
];
