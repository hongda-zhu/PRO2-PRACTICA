var searchData=
[
  ['prcd_144',['prcd',['../classCluster.html#ab45e3f2ff20deab90a7deccbdeef8898',1,'Cluster']]],
  ['prcd_5fdata_145',['prcd_data',['../classCluster.html#a36df9157f86a532fd3a56c21eb806068',1,'Cluster']]],
  ['prcd_5fjob_5fmemory_146',['prcd_job_memory',['../classProcesador.html#af4560dbbadd8a4456fa2c2ae94624067',1,'Procesador']]],
  ['prcd_5fmemory_5fjob_147',['prcd_memory_job',['../classProcesador.html#a84b9a006ace320f9101e998ce71f5994',1,'Procesador']]],
  ['prioridades_5fdata_148',['prioridades_data',['../classArea__Espera.html#a06ff5337d7b5c7870f6e33bc7ca35164',1,'Area_Espera']]]
];
