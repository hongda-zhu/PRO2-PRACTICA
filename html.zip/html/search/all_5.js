var searchData=
[
  ['gap_5fdata_22',['gap_data',['../classProcesador.html#a36e8cb7fa64b229ac3d231a4211e9a84',1,'Procesador']]]
];
