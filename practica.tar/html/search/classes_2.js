var searchData=
[
  ['prioridad_75',['Prioridad',['../classPrioridad.html',1,'']]],
  ['procesador_76',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_77',['Proceso',['../classProceso.html',1,'']]]
];
