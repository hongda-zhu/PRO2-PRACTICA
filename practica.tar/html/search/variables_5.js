var searchData=
[
  ['memory_141',['memory',['../classProcesador.html#ae6bb3892fd8f5d7bc45330ae0882bad6',1,'Procesador']]]
];
