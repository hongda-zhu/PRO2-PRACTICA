var searchData=
[
  ['cluster_98',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster']]],
  ['compactar_5fmemoria_5fcluster_99',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_100',['compactar_memoria_procesador',['../classCluster.html#aaee8f13b3a7cd82b06ae5decd7f80bf0',1,'Cluster::compactar_memoria_procesador()'],['../classProcesador.html#a6c5d44f2b2e9aee6553a77d3056626f0',1,'Procesador::compactar_memoria_procesador()']]],
  ['configurar_5fcluster_101',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]]
];
